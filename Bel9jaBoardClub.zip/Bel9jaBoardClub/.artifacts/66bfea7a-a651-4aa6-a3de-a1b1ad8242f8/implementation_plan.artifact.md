# Implementation Plan - Fix Build Error: Daemon compilation failed: null

The project is currently experiencing a Kotlin compiler daemon crash (`Daemon compilation failed: null`). This is caused by a version mismatch:
- **Gradle:** 9.3.0
- **Android Gradle Plugin (AGP):** 8.5.2 (Incompatible with Gradle 9.3.0)
- **Kotlin:** 1.9.24 (Incompatible with the current Java 26 environment)

I will upgrade the project to use AGP 9.4.0 and Kotlin 2.4.20, which are compatible with Gradle 9.3.0 and newer JVMs.

## Proposed Changes

### Build Configuration

#### [MODIFY] [build.gradle.kts](file:///Users/vladakulyk/Downloads/Bel9jaBoardClub/build.gradle.kts)
- Upgrade AGP version to `9.4.0`.
- Upgrade Kotlin version to `2.4.20`.
- Add the Kotlin Compose compiler plugin declaration.

#### [MODIFY] [app/build.gradle.kts](file:///Users/vladakulyk/Downloads/Bel9jaBoardClub/app/build.gradle.kts)
- Apply `org.jetbrains.kotlin.plugin.compose`.
- Remove `composeOptions` block (deprecated in Kotlin 2.0+).
- Update `compileSdk` and `targetSdk` to `35`.
- Update Java compatibility and `jvmTarget` to `17`.

#### [MODIFY] [gradle.properties](file:///Users/vladakulyk/Downloads/Bel9jaBoardClub/gradle.properties)
- Add `android.newDsl=false` if needed to maintain compatibility during transition (optional, but safer).
- Ensure `android.useAndroidX=true`.

## Verification Plan

### Automated Tests
- Run `./gradlew clean :app:compileDebugKotlin` to verify the Kotlin compilation issue is resolved.
- Run `./gradlew assembleDebug` to ensure the full build succeeds.

### Manual Verification
- Verify that the IDE syncs successfully after the changes.
